        <div class="table-responsive">
            <table class="table table-striped table-bordered table-condensed table-hover" ">
                <thead>
                    <th>Id Anuncio</th>
                    <th>Titulo</th>
                    <th>descripcion</th>
                    <th>Fecha Inicio</th>
                    <th>Fecha Final</th>
                    <th>Activo</th>
                    <th>Localidad</th>
                    <th>Id Usuario</th>

                </thead>
<?php if(count($anuncios)>0): ?>
                <tbody>
                    <?php $__currentLoopData = $anuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($anu->idanuncio); ?></td>
                        <td><?php echo e($anu->titulo); ?></td>
                        <td><?php echo e($anu->descripcion); ?></td>
                        <td><?php echo e($anu->fechainicio); ?></td>
                        <td><?php echo e($anu->fechafinal); ?></td>                     
                        <td><?php echo e($anu->activo); ?></td>                     
                        <td><?php echo e($anu->NombreLocalidad); ?></td>                     
                        <td>
                            <a href="<?php echo e(URL::action('UsuarioController@edit',$anu->idusuario)); ?>">
                                <?php echo e($anu->NombreUsuario); ?>

                            </a>
                        </td>                                             
                        <td>

                            <a href="<?php echo e(URL::action('AnuncioController@edit',$anu->idanuncio)); ?>">
                                <i class="fa fa-pencil-square-o fa-2x" aria-hidden="true">
                                </i>
                            </a>

                            <i class="fa fa-camera-retro fa-2x delete-modal " color=#00c0ef data-id="<?php echo e($anu->idanuncio); ?>"></i> 
                            
                        </td>                   
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

<?php else: ?>
                <tbody>
                    <tr>
                        <td colspan=5 align="center"><b>No hay resultados en la búsqueda</b></td>

                    </tr>
                </tbody>

<?php endif; ?>
            </table>
            <?php echo e($anuncios->links()); ?>

        </div>
