<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<p><stron>Nombre: </stron><?php echo $nombre; ?></p>
	<p><stron>Correo: </stron><?php echo $email; ?></p>
	<p><stron>Mensaje: </stron><?php echo $tipo_usuario; ?></p>
</body>
</html>