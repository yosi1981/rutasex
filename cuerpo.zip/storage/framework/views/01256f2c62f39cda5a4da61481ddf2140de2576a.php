<?php $__env->startSection('contenido'); ?>


<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">

		<h3>Listado de Provincias 
			
				<button id="btnAddProvincia" name="btnAddProvincia" class="btn btn-success">Nuevo</button>
	
		</h3>
		<?php echo $__env->make('provincia.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>
<?php echo $__env->make('provincia.nuevaProvincia', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
<?php echo $__env->make('provincia.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="col-lg-12 ccol-md-12 col-sm-12 col-xs-12" >
	
		<div class="table-responsive" id="cuerpo" name="cuerpo">
			<table class="table table-striped table-bordered table-condensed table-hover" >
				<thead>
					<th>Id Provincia</th>
					<th>Nombre</th>
					<th>Habilitado</th>
					<th>Responsable</th>
					<th>Opciones</th>
				</thead>
				<tbody>
					<?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($provi->idprovincia); ?></td>
						<td><?php echo e($provi->nombre); ?></td>
						<td><?php echo e($provi->habilitado); ?></td>
						<td>
							<a href="<?php echo e(URL::action('UsuarioController@edit',$provi->idresponsable)); ?>">
								<?php echo e($provi->NombreUsuario); ?>

							</a>
						</td>
						<td>
							<a href="<?php echo e(URL::action('ProvinciaController@edit',$provi->idprovincia)); ?>"><button class="btn btn-info">Editar</button></a>
							<?php if($provi->habilitado==1): ?> 
								<button class="delete-modal btn btn-warning" data-id="<?php echo e($provi->idprovincia); ?>">DESHABILITAR</button>
							<?php else: ?>
								<button class="delete-modal btn btn-success" data-id="<?php echo e($provi->idprovincia); ?>">HABILITAR</button>
							<?php endif; ?>
						</td>					
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			<?php echo e($provincias->links()); ?>

		</div>
	</div>
</div>
<script type="text/javascript">
	$('#searchText').on('keyup',function(){
		$value=$(this).val();
		$.ajax({
			type : 'get',
			url  : '<?php echo e(URL::to('/admin/searchProvincia')); ?>',
			data : {'searchText' : $value},
			async: true,
    		dataType: 'json',
    		headers: {
                       'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                 },
			success:function(data){
				$('#cuerpo').html(data);
			}
		})
	})
	$(document).on('click','.pagination a',function(e){
		e.preventDefault();
		var page=$(this).attr('href').split('page=')[1];
		getProvincias(page,$('#searchText').val());
	})

	function getProvincias(page,search)
	{
		var url="<?php echo e(URL::to('/admin/searchProvincia')); ?>";
		$.ajax({
			type : 'get',
			url  : url+'?page='+page,
			data : {'searchText': search}
		}).done(function(data){
			$('#cuerpo').html(data);
		})
	}


  		$('#btnAddProvincia').on('click',function(){
	    	$('#Provincia').modal('show');
	    })

    	$('#frmProvincia').on('submit',function(e){
    		e.preventDefault();
    		var form=$('#frmProvincia');
    		var formData=form.serialize();
    		var url=form.attr('action');
    		$.ajax({
    			type:'post',
    			url: url,
    			data: formData,
    			async: true,
    			dataType: 'json',
    			headers: {
                       'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                   },
    			success:function(data){
    				alert("llego");
     				$('#Provincia').modal('hide');
    				getProvincias(1,"");
    			}

    		}).fail(function(data){

    			    		})
    	})

    	
    	$(document).on('click', '.delete-modal', function(){
    		$('.id').text($(this).data('id'));
    		$('#modal-delete').modal('show');
    	})
		$('.modal-footer').on('click', '.delete', function(e) {
			e.preventDefault();
			var url="<?php echo e(URL::to('/admin/eliminarProvincia')); ?>";
		  $.ajax({
		    type: 'post',
		    data: {
		      'id': $('.id').text()
		    },
		    url: url,
   			headers: {
                       'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                   },
		    success: function(data) {
		    $('#modal-delete').modal('hide');
		    getProvincias(1,"");
		    $('.modal-backdrop').removeClass();
		    }
		  });
		});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>