<?php $__env->startSection('contenido'); ?>

<h1>Ingresos:</h1>

  <div class="row">
 <?php echo e(Form::open(array('url' => '/payment','method'=>'GET'), array('role' => 'form'))); ?>


  <div class="row">
    <div class="form-group col-md-4">
      <?php echo e(Form::label('Dias', 'Número de dias: ')); ?>

      <?php echo e(Form::text('Dias', null, array('placeholder' => 'Introduce el número de dias', 'class' => 'form-control'))); ?>

    </div>
  </div>
  <?php echo e(Form::button('Realizar pago', array('type' => 'submit', 'class' => 'btn btn-primary'))); ?>    
  
<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>