
				<label for="idlocalidad">localidad</label>
				{!! Form::select('idlocalidad',$provincias,null,$attributes = array('class'=>'form-control'))!!}