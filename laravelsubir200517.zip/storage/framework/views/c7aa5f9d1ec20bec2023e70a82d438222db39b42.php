


			<table class="table table-striped table-bordered table-condensed table-hover" >
				<thead>
					<h3>ANUNCIOS EN TUS PROVINCIAS DELEGADAS</h3>
				</thead>
				<tbody>
					<?php $__currentLoopData = $usuario->DatosUsuario->ProvinciasGestionaDelegado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provDelega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
					<td><?php echo e($provDelega->id); ?></td>
					<td><?php echo e($provDelega->nombre); ?></td>
					<td><?php echo e(count($provDelega->anunciosHistorial->where('iddelegado',$usuario->id))); ?></td>
					</tr>
					<tr>
						<td colspan=3>
						<table class="table table-striped table-bordered table-condensed table-hover" >
						<thead>
							
						</thead>
						<tbody>
								<?php $__currentLoopData = $provDelega->anunciosHistorial->where('iddelegado',$usuario->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anuncio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($anuncio->id); ?></td>
									<td><?php echo e($anuncio->fecha); ?></td>
									<td><?php echo e($anuncio->idanuncio); ?></td>
									<td><?php echo e($anuncio->numvisitas); ?></td>							
								</tr>		
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
						</tbody>

						</table>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
