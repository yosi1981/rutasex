

			<table class="table table-striped table-bordered table-condensed table-hover" >
				<thead>
					<h3>ANUNCIOS DE TUS REFERIDOS</h3>
				</thead>
				<tbody>
					<?php $__currentLoopData = $usuario->Referidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
					<td><?php echo e($referido->id); ?></td>
					<td><?php echo e($referido->Usuario->email); ?></td>
					<td><?php echo e(count($referido->HistorialAnuncios)); ?></td>
					</tr>
					<tr>
						<td colspan=3>
							<table class="table table-striped table-bordered table-condensed table-hover" >
							<thead>
								
							</thead>
							<tbody>
								<?php $__currentLoopData = $referido->HistorialAnuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anuncioreferido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($anuncioreferido->id); ?></td>
										<td><?php echo e($anuncioreferido->fecha); ?></td>
										<td><?php echo e($anuncioreferido->idanuncio); ?></td>
										<td><?php echo e($anuncioreferido->numvisitas); ?></td>							
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>						
							</tbody>

							</table>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
