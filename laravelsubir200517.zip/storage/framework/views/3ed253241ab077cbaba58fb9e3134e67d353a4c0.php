
		<?php $__currentLoopData = $usuario->DatosUsuario->ProvinciasGestionaAdminProv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provGestiona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<table class="table table-striped table-bordered table-condensed table-hover" >
				<thead>
					<h3>ANUNCIOS EN TUS PROVINCIAS</h3>
				</thead>
				<tbody>
					<tr>
					<td><?php echo e($provGestiona->id); ?></td>
					<td><?php echo e($provGestiona->name); ?></td>
					<td><?php echo e(count($provGestiona->anunciosHistorial->where('idadminPro',$usuario->id))); ?><td>
					</tr>
					<tr>
						<table class="table table-striped table-bordered table-condensed table-hover" >
						<thead>
							
						</thead>
						<tbody>
								<?php $__currentLoopData = $provGestiona->anunciosHistorial->where('idadminPro',$usuario->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anuncio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($anuncio->id); ?></td>
									<td><?php echo e($anuncio->fecha); ?></td>
									<td><?php echo e($anuncio->idanuncio); ?></td>
									<td><?php echo e($anuncio->numvisitas); ?></td>							
								</tr>	
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						</tbody>

						</table>
					</tr>
				</tbody>
			</table>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>