<?php echo Form::open(array('url' => '/pruebaCheckbox1')); ?> 

<?php echo Form::label('Test-1'); ?> <?php echo Form::checkbox('ch[]', 'value-1', false);; ?> 

<?php echo Form::label('Test-2'); ?> <?php echo Form::checkbox('ch[]', 'value-2', false);; ?> 

<?php echo Form::submit('Click Me!'); ?>

<?php echo Form::close(); ?>