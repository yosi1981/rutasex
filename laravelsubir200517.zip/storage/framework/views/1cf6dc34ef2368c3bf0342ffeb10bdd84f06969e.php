		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover" ">
				<thead>
					<th>Id Usuario</th>
					<th>Usuario</th>
					<th>Email</th>
					<th>Activo</th>
					<th>Tipo</th>
					<th>Opciones</th>
				</thead>
<?php if(count($usuarios)>0): ?>
				<tbody>
					<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($usu->id); ?></td>
						<td><?php echo e($usu->name); ?></td>
						<td><?php echo e($usu->email); ?></td>
						<td><?php echo e($usu->activo); ?></td>
						<td><?php echo e($usu->stringRol->nombre); ?></td>						
						<td>
                            <a href="<?php echo e(URL::action('UsuarioController@edit',$usu->id)); ?>">
                                <i class="fa fa-pencil-square-o fa-2x" aria-hidden="true" data-toggle="tooltip" data-placement="right" title="Editar Usuario">
                                </i>
                            </a>
							<a href="<?php echo e(URL::action('UsuarioController@IniciarSesion',$usu->id)); ?>" data-toggle="tooltip" data-placement="right" title="Iniciar sesion como ... <?php echo e($usu->name); ?>"><i class="fa fa fa-bolt fa-2x" ></i></a>
                            <i class="fa fa-camera-retro fa-2x delete-modal " data-toggle="tooltip" data-placement="right" title="Eliminar Usuario" color=#00c0ef data-id="<?php echo e($usu->id); ?>"></i> 
					</td>					
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>

<?php else: ?>
				<tbody>
					<tr>
						<td colspan=5 align="center"><b>No hay resultados en la búsqueda</b></td>

					</tr>
				</tbody>

<?php endif; ?>
			</table>
			<?php echo e($usuarios->links()); ?>

		</div>
