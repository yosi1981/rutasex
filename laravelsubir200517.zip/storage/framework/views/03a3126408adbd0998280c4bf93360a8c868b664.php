          <ul class="sidebar-menu">
            <li class="header"></li>
            
            <li class="treeview active">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Provincia</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(asset('/anunciante/Provincia')); ?>"><i class="fa fa-user"></i> Provincia</a></li>
                <li><a href="<?php echo e(asset('/anunciante/Imagen')); ?>"><i class="fa fa-user "></i> Imagen</a></li>
                <li><a href="<?php echo e(asset('/anunciante/Anuncio')); ?>"><i class="fa fa-user"></i> Anuncio</a></li>
                <li><a href="<?php echo e(asset('/anunciante/Usuario')); ?>"><i class="fa fa-user"></i> Usuario</a></li>
                </li>
                <li><a href="<?php echo e(asset('/infocuenta')); ?>"><i class="fa fa-user"></i> Mi cuenta</a></li>
              </ul>
            </li>

            <li class="treeview active">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>GESTION</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(asset('/anunciante/ContratarDias')); ?>"><i class="fa fa-user"></i> Contratar Dias</a></li>
                <li><a href="<?php echo e(asset('/anunciante/Imagen')); ?>"><i class="fa fa-user "></i> Imagen</a></li>
                <li><a href="<?php echo e(asset('/anunciante/Anuncio')); ?>"><i class="fa fa-user"></i> Anuncio</a></li>
                <li><a href="<?php echo e(asset('/anunciante/Usuario')); ?>"><i class="fa fa-user"></i> Usuario</a></li>
              </ul>
            </li>

            <!--
            <li class="treeview">
              <a href="#">
                <i class="fa fa-th"></i>
                <span>Compras</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="compras/ingreso"><i class="fa fa-circle-o"></i> Ingresos</a></li>
                <li><a href="compras/proveedor"><i class="fa fa-circle-o"></i> Proveedores</a></li>
              </ul>
            </li>
            -->
