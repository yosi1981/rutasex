<?php $__env->startSection('barraizquierda'); ?>
<?php if(count($provincias)>0): ?>
        <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($provincia->idprovincia==$pro->idprovincia): ?>
            <li class="selected"><a href="<?php echo e(URL::action('PrincipalController@mostrarAnuncios',$pro->idprovincia)); ?>"><?php echo e($pro->nombre); ?></a>
            <i class="fa fa-angle-left pull-right"></i></li>
            <?php else: ?>
            <li><a href="<?php echo e(URL::action('PrincipalController@mostrarAnuncios',$pro->idprovincia)); ?>"><?php echo e($pro->nombre); ?></a>
            <i class="fa fa-2x fa-angle-left pull-right"></i></li>            
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php if(count($anuncios)>0): ?>
    <?php $__currentLoopData = $anuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product_box">
        <img src="<?php echo e(asset('img/p1.gif')); ?>" alt="" title="" class="prod_image" />
        <div class="product_details">
            <div class="prod_title"><?php echo e($anu->titulo); ?></div>
            <p>
            <?php echo e($anu->descripcion); ?>

            </p>
            <div class="prod_title"><?php echo e($anu->NombreLocalidad); ?>ahsdfkjhasd</div>
            <a href="details.html" class="details"><img src="<?php echo e(asset('img/details.gif')); ?>" alt="" title="" border="0"/></a>
        </div>
        </div>


      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>

        <div class="product_box">
        <img src="<?php echo e(asset('img/p1.gif')); ?>" alt="" title="" class="prod_image" />
        <div class="product_details">
            <div class="prod_title">xxxxxx</div>
            <p>
            xxxxxx
            </p>
            <p class="price"><span class="price">xxxxx</span></p>
            <a href="details.html" class="details"><img src="<?php echo e(asset('img/details.gif')); ?>" alt="" title="" border="0"/></a>
        </div>
        </div>

<?php endif; ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>