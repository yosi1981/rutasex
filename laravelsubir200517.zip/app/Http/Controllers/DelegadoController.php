<?php

namespace App\Http\Controllers;

class DelegadoController extends Controller
{
    public function Dashboard()
    {
        return view("delegado.Dashboard");

    }

}
