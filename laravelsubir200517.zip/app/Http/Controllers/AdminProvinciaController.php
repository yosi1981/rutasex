<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminProvinciaController extends Controller
{
    public function Dashboard()
    {
        return view("adminProvincia.Dashboard");

    }

}
