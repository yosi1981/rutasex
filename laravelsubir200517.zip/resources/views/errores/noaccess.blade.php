<!DOCTYPE html>
<html>
<head>
	<title>LA RUTA DEL SEXO</title>
</head>
<body>
		<p>
			{{$msj}}
		</p>
</body>
</html>