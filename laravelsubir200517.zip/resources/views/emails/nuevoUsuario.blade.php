<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<p><stron>Nombre: </stron>{!!$nombre!!}</p>
	<p><stron>Correo: </stron>{!!$email!!}</p>
	<p><stron>Mensaje: </stron>{!!$tipo_usuario!!}</p>
</body>
</html>